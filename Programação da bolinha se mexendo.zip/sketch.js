var width = 600;
var heigth = 400;

var xBolinha = 300;
var yBolinha = 200;
var dBolinha = 20;

var velocidadeXBolinha = 3;
var velocidadeYBolinha = 3;

function setup() {
  createCanvas(600, 400); // (largura, altura)
}

  function criarBolinha() {
      circle(xBolinha, yBolinha, dBolinha); //(eixo x, eixo y, diâmetro)
  }
  
 function movimentarBolinha() {
  xBolinha = xBolinha + velocidadeXBolinha;
  yBolinha = yBolinha + velocidadeYBolinha;
 }
  
function verificarColisão(){
    if(xBolinha > width || xBolinha < 0)
    {
      velocidadeXBolinha = -1 * velocidadeXBolinha;
    }
  if(yBolinha > heigth || yBolinha < 0)
    {
      velocidadeYBolinha = -1 * velocidadeYBolinha;
    }
}


function draw() {
  background("#A020F0");
  criarBolinha();
  movimentarBolinha();
  verificarColisão();
}